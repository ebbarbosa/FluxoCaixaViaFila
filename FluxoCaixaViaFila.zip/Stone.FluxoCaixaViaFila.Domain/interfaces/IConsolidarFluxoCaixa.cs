using System.Collections.Generic;

namespace Stone.FluxoCaixaViaFila.Domain
{
    public interface IConsolidarFluxoCaixa
    {
        FluxoCaixa ConsolidarMes();
    }
}


