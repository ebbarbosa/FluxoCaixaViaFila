﻿namespace Stone.FluxoCaixaViaFila.Domain
{
    public interface IRecebimentoMq : IMessageMq
    {
    }
}