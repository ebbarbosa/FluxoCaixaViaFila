﻿namespace Stone.FluxoCaixaViaFila.Domain
{
	public interface ILancamentoSpecification
	{
		void Validate();
	}
}