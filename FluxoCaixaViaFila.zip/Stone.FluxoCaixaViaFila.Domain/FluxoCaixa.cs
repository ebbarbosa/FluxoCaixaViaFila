using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Stone.FluxoCaixaViaFila.Domain
{
    [JsonArray]
    public class FluxoCaixa : ICollection<FluxoCaixaDiario>
    {
        private ICollection<FluxoCaixaDiario> consolidado;

        public FluxoCaixa(IEnumerable<FluxoCaixaDiario> consolidado)
        {
            this.consolidado = new List<FluxoCaixaDiario>(consolidado);
            if (consolidado == null) consolidado = new List<FluxoCaixaDiario>();
        }

        public int Count => consolidado.Count;

        public bool IsReadOnly => consolidado.IsReadOnly;

        public void Add(FluxoCaixaDiario item)
        {
            consolidado.Add(item);
        }

        public void Clear()
        {
            consolidado?.Clear();
        }

        public bool Contains(FluxoCaixaDiario item)
        {
            return consolidado.Contains(item);
        }

        public void CopyTo(FluxoCaixaDiario[] array, int arrayIndex)
        {
            consolidado?.CopyTo(array, arrayIndex);
        }

        public IEnumerator<FluxoCaixaDiario> GetEnumerator()
        {
            return consolidado?.GetEnumerator();
        }

        public bool Remove(FluxoCaixaDiario item)
        {
            return consolidado.Remove(item);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return consolidado?.GetEnumerator();
        }

        public FluxoCaixaDiario GetPorDia(DateTime dataLancamento)
        {
            return consolidado?.FirstOrDefault(c => c.Data.Date.Equals(dataLancamento.Date));
        }
    }
}


