﻿namespace Stone.FluxoCaixaViaFila.Domain
{
    public interface ILancamentoRouter
    {
        void RotearPraFila(Lancamento lancamento);
    }
}