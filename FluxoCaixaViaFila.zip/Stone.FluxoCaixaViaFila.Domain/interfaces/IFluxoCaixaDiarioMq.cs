﻿namespace Stone.FluxoCaixaViaFila.Domain
{
    public interface IFluxoCaixaDiarioMq : IPublisherMq
    {
    }
}